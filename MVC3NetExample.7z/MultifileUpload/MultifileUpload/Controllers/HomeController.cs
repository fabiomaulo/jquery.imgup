﻿using System;
using System.IO;
using System.Web;
using System.Web.Mvc;

namespace MultifileUpload.Controllers
{
	public class HomeController : Controller
	{
		//
		// GET: /Home/

		public ActionResult Index()
		{
			return View();
		}

		[HttpPost]
		public ActionResult UploadTempimgs(Guid editTransactionId, HttpPostedFileBase image)
		{
			string storageTempPath = Path.Combine(HttpContext.Server.MapPath("/"), "Images", "Temp");
			string editTransactionFolder = Path.Combine(storageTempPath, editTransactionId.ToString("N"));
			Directory.CreateDirectory(editTransactionFolder);
			string newFileName = "I" + Guid.NewGuid().ToString("N") + ".jpg";
			string tempPath = Path.Combine(editTransactionFolder, newFileName);
			image.SaveAs(tempPath);
			string tempFileWebPath = string.Format("/Images/Temp/{0}/{1}", editTransactionId.ToString("N"), newFileName);
			return Json(new {uploadPath = tempFileWebPath});
		}
	}
}